<?php
global $wpdb;
$table_name=$wpdb->prefix.'table_form';
$urlp= admin_url('admin.php?page=custom_plugin');
if(isset($_GET['repid'])){
    $id=$_GET['repid'];
    $db_results=$wpdb->get_results("select email from $table_name where id=$id");
//    $urlp= admin_url('admin.php?page=custom_plugin');
//    wp_redirect($urlp);
}
if(isset($_POST['sub'])){
    $urlp= admin_url('admin.php?page=custom_plugin');
   wp_redirect($urlp);
}
function sub()
{
    $urlp= admin_url('admin.php?page=custom_plugin');
    wp_redirect($urlp);
}

?>

<div class="container">
      <div class="row align-items-stretch no-gutters contact-wrap">
        <div class="col-md-12">
          <div class="form h-100">
            <h3>Replay</h3>
            <form class="mb-5" action="mailto:<?php echo $db_results[0]->email ?>" method="post" encytype="text/plain" >
            <div class="form-group">
            <label for="mail"> email</label>
            <input type="text" class="form-control" id="mail"  value="<?php echo $db_results[0]->email ?>" readonly>
            </div>
            <div class="row form-group">
            <label for="res"> response</label>
            <input  class="form-control" type="text" name="response" id="res" cols="30" rows="10" />
            </div>            
            <input type="submit" class="btn btn-primary" value="send" ><br>
            <a href="<?php echo $urlp ?>"  class="btn btn-primary ">go back</a>
        </form>
          
         </div>
        </div>
     </div>
</div>

<style>
input[type=text], select {
  width: 90%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

input[type=submit] {
  width: 90%;
  background-color: #000;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}



</style>
