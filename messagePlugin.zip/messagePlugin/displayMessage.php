<?php
global $wpdb;
$table_name=$wpdb->prefix.'table_form';
$db_results=$wpdb->get_results("select * from $table_name");
global $wp;
$urlc= add_query_arg( $wp->query_vars, home_url() );;
if(isset($_GET['delid'])){
 $wpdb->delete( $table_name, array( 'id' => $_GET['delid'] ) );
   $urlp= admin_url('admin.php?page=custom_plugin');
   wp_redirect($urlp);
    // header('location:'.$urlp);
}
?>

<div>
<table class="table table-dark">
  <thead>
    <tr>

      <th scope="col">first name</th>
      <th scope="col">last name</th>
      <th scope="col">email</th>
      <th scope="col">subject</th>
      <th scope="col">message</th>
      <th scope="col">action</th>
    </tr>
  </thead>
  <tbody>
  <?php foreach($db_results as $row){ ?>
<tr>
<td scope="row"><?php echo $row->fstname ?></td>
<td><?php echo $row->lstname ?></td>
<td><?php echo $row->email ?></td>
<td><?php echo $row->subject ?></td>
<td><?php echo $row->message ?></td>
<td> <a href="<?php echo $urlc.'&delid='.$row->id  ?>" > delete</a> &nbsp;&nbsp;  <a href="<?php echo $urlc.'&repid='.$row->id  ?>">Replay</a></td>
</tr>
<?php } ?>
  </tbody>
</table>
</div>
<style>
table {
  margin-top:5%;
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 90%;
}

table td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}


table tr:hover {background-color: #ddd;}

table th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #000;
  color: white;
}
</style>